#Kristjan Juhansoo IS25
from random import randint
tulemus = randint(1, 999)
while True:
    try:
        arv = int(input("Sisesta arv: "))
    except ValueError:
        print("Sisesta arv mitte tekst")
        continue
    if arv < tulemus:
        print ("Arv on liiga väike")
    elif arv > tulemus:
        print ("Arv on liiga suur")
    elif arv == tulemus:
        print ("Arv oli õige!")
        break